# Kidney-Exchange-LP
## By Mike Bao, Jonathan Huang, and Michelle Chen
#### Project for APMTH 121, Fall 2018

All outputs are in the output folder. All models as well as .mod and .dat files included in the models folder. All visualizations generated in the images folder.

In the models folder, all files are named ex_.* based on which exercise the code is for and what filetype the code is.